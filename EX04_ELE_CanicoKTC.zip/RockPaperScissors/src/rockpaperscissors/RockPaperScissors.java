package rockpaperscissors;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class RockPaperScissors{
    public static void main(String[] args) throws IOException{
        Move rock = new Move("Rock");
        Move paper = new Move("Paper");
        Move scissors = new Move("Scissors");

        rock.setStrongAgainst(scissors);
        paper.setStrongAgainst(rock);
        scissors.setStrongAgainst(paper);
        
        do{
            InputStreamReader in = new InputStreamReader(System.in);
            BufferedReader re = new BufferedReader(in);
            Scanner sc = new Scanner(System.in);
            int roundsToWin = 2;
            int i = 0, m1point = 0, m2point = 0;

            System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option:\n1. Start game\n" + "2. Change number of rounds\n" + "3. Exit application\ninput: ");
            int start = sc.nextInt();
            switch (start) {
                case 2:
                    System.out.println("\nHow many wins needed to win a match?\ninput: ");
                    roundsToWin = sc.nextInt();
                    break;
                case 3:
                    System.out.println("Thanks for playing!");
                    System.exit(0);
            }
            System.out.println("\nThis match will be first to " + roundsToWin + " wins.");
            do {
                Move playerMove = new Move("Player");
                Move computerMove = new Move("Computer");
                Move victoryMove = new Move("Victory");
                int random = (int) Math.floor(Math.random()*3) + 1;

                //player input
                System.out.println("\nThe computer has selected its move. Select your move: \n1. Rock\n2. Paper\n3. Scissors\ninput: ");
                int player = sc.nextInt();    

                //converts int input to Move type
                playerMove = playerMove.convertMove(player, playerMove, rock, paper, scissors);
                computerMove = computerMove.convertMove(random, computerMove, rock, paper, scissors);

                //receives output of .compareMove method
                int victory = victoryMove.compareMoves(playerMove, computerMove);

                //prints participant choices
                System.out.println("\nPlayer chose " + playerMove.name + ". Computer chose " + computerMove.name + ". ");

                //if victory = 0, player wins ; if victory = 1, computer wins; otherwise nobody won
                String victor = (victory == 0) ? "Player " : (victory == 1) ? "Computer " : "Nobody ";
                System.out.println(victor + "wins round!\n\n");

                //points logic, add points only if victory condition is met
                if (victory == 0) m1point++;
                else if (victory == 1) m2point++;

                System.out.println("Player: " + m1point + " - Computer: " + m2point);
                i++;
            } while ((m2point<roundsToWin)&&(m1point<roundsToWin));
            if (m1point>m2point) System.out.println("Player Wins!\n\n");
            else System.out.println("Computer Wins!\n\n");
        } while (1<3);
    }
}
