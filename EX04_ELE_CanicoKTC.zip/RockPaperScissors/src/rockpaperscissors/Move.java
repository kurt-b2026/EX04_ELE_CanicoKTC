package rockpaperscissors;

public class Move {
    final String name;
	private Move strongAgainst;
    
    public Move(String name){
        this.name = name;
        this.strongAgainst = null;
    }
	public String getName(){
		return this.name;
	}
	public Move getStrongAgainst(){
		return this.strongAgainst;
	}
	public void setStrongAgainst(Move strongAgainst){
		this.strongAgainst = strongAgainst;
	}
    public int compareMoves(Move m1, Move m2){
		// This method returns 0 if m1 wins, 1 if m2 wins, and 2 if neither wins
		if(m1.getStrongAgainst() ==  m2) return 0;
		else if (m2.getStrongAgainst() == m1) return 1;
		else return 2;
	}
    
    //for converting the stuff
    public Move convertMove(int move, Move choice, Move m1, Move m2, Move m3){
        switch (move) {
            case 1:
                choice = m1;
                break;
            case 2:
                choice = m2;
                break;
            case 3: 
                choice = m3;
                break;
        }
        return choice;
    }
}
